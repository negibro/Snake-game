# Snake Classic

A classic Snake game for Android phones (Kotlin, native Android, custom Canvas board).
Works fully offline, needs **no permissions**, no internet, no accounts, and has **zero third-party dependencies**.

- App name: **Snake Classic** · Application ID: `com.example.snakeclassic` · Min Android 7.0 (API 24) · Portrait only
- Swipe controls (default) or an on-screen D-pad (toggle on the home screen)
- Best score saved on the phone; sound effects are generated in code (original, nothing to license)

---

## Build status: please read

The APK **was not built** in the environment where this project was written (it had no Android SDK and
its network blocked the SDK/Maven downloads). So there is **no APK file in this download** — you
generate it yourself with one of the two options below. Both are free and take ~10 minutes the first time.

What *was* verified:

| Check | Result |
|---|---|
| Game rules (movement, reversal blocking, growth, scoring, walls, self-collision, tail-cell rule, food never on snake, speed-up, winning) | **15 unit tests compiled with Kotlin 2.0.21 and passed** |
| All XML files well-formed; every `@string/@color/@drawable/@style/@mipmap` and `R.id.*` reference resolves | **Checked by script** |

What was **not** verified (could not be run here): the Gradle build itself, compilation of the Android-specific
Kotlin files (`MainActivity`, `SnakeView`, `SoundManager`, etc.), and running the app on a device/emulator.
Swipes, pause/resume, sound, lifecycle handling and persistence of the best score have therefore **not been
tested on a real phone**. If the build reports an error, see Troubleshooting and tell me the message.

---

## Option A (recommended): build with Android Studio

1. Install **Android Studio** (free): https://developer.android.com/studio
2. Open Android Studio → **Open** → choose the `SnakeClassic` folder (the one containing `settings.gradle.kts`).
3. Wait for **Gradle sync** to finish (bottom bar). The first time it downloads the Android SDK pieces it needs; if it asks to
   install SDK Platform 34 or accept licences, click the link / **Accept**.
4. Menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. When a popup says "APK(s) generated successfully", click **locate**.

The file is at:

```
SnakeClassic/app/build/outputs/apk/debug/app-debug.apk
```

### Or from a terminal (after Android Studio has installed the SDK once)

```
cd SnakeClassic
./gradlew assembleDebug          # Windows: gradlew.bat assembleDebug
```

If it complains the SDK was not found, create a file `local.properties` next to `settings.gradle.kts`:
`sdk.dir=/path/to/Android/Sdk` (Windows: `sdk.dir=C\:\\Users\\YOU\\AppData\\Local\\Android\\Sdk`).
Android Studio normally creates this for you.

## Option B: let GitHub build it (no software to install)

1. Create a free account at https://github.com and make a **new repository** (private is fine).
2. Upload the *contents* of the `SnakeClassic` folder (including the hidden `.github` folder) to it.
3. Open the **Actions** tab → **Build debug APK** → **Run workflow** (it also runs automatically on every upload).
4. When the run finishes (green tick), open it and download **SnakeClassic-debug-apk** from *Artifacts*.
   Unzip it to get `app-debug.apk`.

---

## Install on your phone

1. Copy `app-debug.apk` to the phone: USB cable (drop it in the *Download* folder), Google Drive / email to yourself,
   or Bluetooth/Nearby Share.
2. On the phone open **Files** (or *Downloads*) and tap `app-debug.apk`.
3. Android will ask you to allow installs from that app (Files/Chrome/Drive): tap **Settings**, switch **Allow from this source** on, go back, tap **Install**.
4. If Play Protect says "unknown app", choose **Install anyway** (it's a debug build signed with a debug key, not from the Play Store).
5. Open **Snake Classic** from your app drawer.

With a cable and USB debugging on you can alternatively run `adb install -r app-debug.apk`.

## Rebuild after changing the code

Edit the files in Android Studio, then repeat **Build → Build APK(s)** (or `./gradlew assembleDebug`).
Install the new APK over the old one (same app ID → your best score is kept). Run the rule tests with `./gradlew testDebugUnitTest`.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `SDK location not found` | Open the project in Android Studio (it writes `local.properties`), or create it with `sdk.dir=...` as above. |
| `Failed to install the following Android SDK packages... licences not accepted` | Android Studio: **Tools → SDK Manager** → install *Android 14 (API 34)*, accept licences. CLI: `sdkmanager --licenses`. |
| `Unsupported class file major version` / `requires Java 17` | Use JDK 17 or newer: Android Studio → **Settings → Build, Execution, Deployment → Build Tools → Gradle → Gradle JDK** → choose *jbr-17* (or newer). |
| `Could not resolve ...` / `Could not GET ...` / timeouts | You're offline or behind a proxy/firewall. Gradle needs the internet **once** to download dependencies. Retry on another network. |
| Sync fails after editing Gradle files | **File → Invalidate Caches → Invalidate and Restart**, then **File → Sync Project with Gradle Files**. |
| `Permission denied: ./gradlew` (Mac/Linux) | `chmod +x gradlew` |
| Compile error in a `.kt` file | Copy the red error text; the line number points at the problem. (The Android-specific code could not be compiled by its author — please report any such error.) |
| Phone: "App not installed" | Uninstall any older copy first (a different signing key blocks updates), free up storage, and make sure the phone runs Android 7.0+. |
| Phone: "Blocked by Play Protect" | Tap **More details → Install anyway**. |
| Can't tap the APK / "can't open file" | Open it from the **Files** app, not from a preview. Make sure the download finished (file size ~1–2 MB). |
| No sound | Check the in-game *Sound* toggle on the home screen and the phone's media volume / silent mode. |

---

## How it works (architecture)

```
app/src/main/java/com/example/snakeclassic/
  MainActivity.kt          wires everything; lifecycle (auto-pause), back button, immersive mode
  game/
    Direction.kt           Direction enum + Cell
    SnakeGame.kt           pure rules: movement, collisions, food, scoring, speed (no Android code)
    GameController.kt      fixed-timestep loop on Choreographer; one loop only; frame-rate independent
  ui/
    SnakeView.kt           Canvas rendering: grid, glowing food, snake with interpolated motion, animations
    ScreenNavigator.kt     Home / Playing / Paused / GameOver layers
  input/
    SwipeDetector.kt       fires on short drags (16 dp) while the finger moves; chained swipes without lifting
  settings/GameSettings.kt best score, sound toggle, control mode (SharedPreferences)
  audio/SoundManager.kt    synthesised beeps written to cache and played via SoundPool
app/src/test/.../SnakeGameTest.kt   15 JVM unit tests for the rules
```

Design notes:
- **Smooth & consistent speed**: logic steps depend on elapsed time (180 ms per step, 3 ms faster per food, floor 75 ms),
  not on frame count, and the renderer interpolates between steps — same speed on 60/90/120 Hz screens.
- **Input**: up to two turns are buffered and each is checked against the *last queued* direction, so rapid
  swipes work but a 180° reversal is impossible.
- **Lifecycle**: the loop stops in `onPause` and when the window loses focus (e.g. notification shade); the game
  shows the Pause screen, and the best score is saved.
- **Board size**: always 20 columns; rows follow the screen height, so cells stay square on any aspect ratio.
