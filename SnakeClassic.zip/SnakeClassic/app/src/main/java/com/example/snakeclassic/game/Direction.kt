package com.example.snakeclassic.game

/** A grid coordinate. x grows to the right, y grows downward. */
data class Cell(val x: Int, val y: Int)

/** The four movement directions with their per-step grid offsets. */
enum class Direction(val dx: Int, val dy: Int) {
    UP(0, -1),
    DOWN(0, 1),
    LEFT(-1, 0),
    RIGHT(1, 0);

    /** True when [other] points exactly the opposite way (a 180-degree reversal). */
    fun isOpposite(other: Direction): Boolean = dx + other.dx == 0 && dy + other.dy == 0
}
