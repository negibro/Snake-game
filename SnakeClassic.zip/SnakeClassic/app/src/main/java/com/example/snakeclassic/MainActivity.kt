package com.example.snakeclassic

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.TextView
import com.example.snakeclassic.audio.SoundManager
import com.example.snakeclassic.game.Cell
import com.example.snakeclassic.game.Direction
import com.example.snakeclassic.game.GameController
import com.example.snakeclassic.settings.GameSettings
import com.example.snakeclassic.ui.Screen
import com.example.snakeclassic.ui.ScreenNavigator
import com.example.snakeclassic.ui.SnakeView
import kotlin.math.max

/**
 * The single activity. It wires together the screens (layout), the game loop
 * ([GameController]), the renderer ([SnakeView]), sound and saved settings, and reacts to
 * Android lifecycle events (pausing when the app goes to the background).
 */
class MainActivity : Activity(), GameController.Listener {

    private lateinit var settings: GameSettings
    private lateinit var sound: SoundManager
    private lateinit var controller: GameController
    private lateinit var navigator: ScreenNavigator

    private lateinit var snakeView: SnakeView
    private lateinit var scoreText: TextView
    private lateinit var bestText: TextView
    private lateinit var homeBestText: TextView
    private lateinit var soundButton: Button
    private lateinit var controlsButton: Button
    private lateinit var dpad: View
    private lateinit var gameOverTitle: TextView
    private lateinit var newBestText: TextView
    private lateinit var finalScoreText: TextView
    private lateinit var gameOverBestText: TextView

    /** Best score when the current game started, used to detect "NEW BEST!". */
    private var bestAtGameStart = 0

    /** True while the death animation plays (the game is over but the overlay isn't shown yet). */
    private var dying = false

    // ---------------------------------------------------------------------------------------
    // Lifecycle
    // ---------------------------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        settings = GameSettings(this)
        sound = SoundManager(this).also { it.enabled = settings.soundEnabled }
        controller = GameController(this)

        bindViews()
        bindButtons()
        applyControlMode()
        refreshHomeTexts()
        navigator.show(Screen.HOME)
    }

    override fun onPause() {
        super.onPause()
        // Never keep the game loop running while in the background.
        pauseGame()
        controller.stop()
    }

    override fun onResume() {
        super.onResume()
        applyImmersiveMode()
        // The game stays paused; the player taps Resume.
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            applyImmersiveMode()
        } else {
            // E.g. the notification shade was pulled down or a system dialog appeared.
            pauseGame()
        }
    }

    override fun onDestroy() {
        controller.stop()
        snakeView.resetEffects()
        sound.release()
        super.onDestroy()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        when (navigator.current) {
            Screen.PLAYING -> pauseGame()
            Screen.PAUSED -> resumeGame()
            Screen.GAME_OVER -> goHome()
            Screen.HOME -> super.onBackPressed()
        }
    }

    // ---------------------------------------------------------------------------------------
    // Setup
    // ---------------------------------------------------------------------------------------

    private fun bindViews() {
        snakeView = findViewById(R.id.snake_view)
        snakeView.keepScreenOn = true
        snakeView.onSwipe = { direction -> controller.queueDirection(direction) }

        scoreText = findViewById(R.id.text_score)
        bestText = findViewById(R.id.text_best)
        homeBestText = findViewById(R.id.text_home_best)
        soundButton = findViewById(R.id.button_sound)
        controlsButton = findViewById(R.id.button_controls)
        dpad = findViewById(R.id.dpad)
        gameOverTitle = findViewById(R.id.text_gameover_title)
        newBestText = findViewById(R.id.text_new_best)
        finalScoreText = findViewById(R.id.text_final_score)
        gameOverBestText = findViewById(R.id.text_gameover_best)

        navigator = ScreenNavigator(
            gameLayer = findViewById(R.id.screen_game),
            homeLayer = findViewById(R.id.screen_home),
            pauseLayer = findViewById(R.id.overlay_pause),
            gameOverLayer = findViewById(R.id.overlay_gameover)
        )
    }

    private fun bindButtons() {
        // Home
        findViewById<Button>(R.id.button_play).setOnClickListener { startGame() }
        soundButton.setOnClickListener { toggleSound() }
        controlsButton.setOnClickListener { toggleControls() }

        // Gameplay
        findViewById<View>(R.id.button_pause).setOnClickListener { pauseGame() }
        bindDpadButton(findViewById(R.id.dpad_up), Direction.UP)
        bindDpadButton(findViewById(R.id.dpad_down), Direction.DOWN)
        bindDpadButton(findViewById(R.id.dpad_left), Direction.LEFT)
        bindDpadButton(findViewById(R.id.dpad_right), Direction.RIGHT)

        // Pause overlay
        findViewById<Button>(R.id.button_resume).setOnClickListener { resumeGame() }
        findViewById<Button>(R.id.button_pause_restart).setOnClickListener { startGame() }
        findViewById<Button>(R.id.button_pause_home).setOnClickListener { goHome() }

        // Game-over overlay
        findViewById<Button>(R.id.button_play_again).setOnClickListener { startGame() }
        findViewById<Button>(R.id.button_gameover_home).setOnClickListener { goHome() }
    }

    /** D-pad buttons react on finger-down (not on release) for the lowest possible input delay. */
    @SuppressLint("ClickableViewAccessibility")
    private fun bindDpadButton(button: View, direction: Direction) {
        button.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    controller.queueDirection(direction)
                }

                MotionEvent.ACTION_UP -> {
                    view.isPressed = false
                    view.performClick()
                }

                MotionEvent.ACTION_CANCEL -> view.isPressed = false
            }
            true
        }
    }

    // ---------------------------------------------------------------------------------------
    // Game flow
    // ---------------------------------------------------------------------------------------

    /** Starts a brand-new game (used by Play, Play Again and Restart). */
    private fun startGame() {
        controller.stop()
        snakeView.whenReady { cols, rows ->
            bestAtGameStart = settings.bestScore
            dying = false
            val game = controller.newGame(cols, rows)
            snakeView.game = game
            snakeView.progress = 0f
            showScore(0, animate = false)
            navigator.show(Screen.PLAYING)
            controller.start()
        }
    }

    private fun pauseGame() {
        if (navigator.current != Screen.PLAYING || dying) return
        controller.stop()
        // Save progress in case the app is killed while paused.
        settings.recordScore(controller.game?.score ?: 0)
        navigator.show(Screen.PAUSED)
    }

    private fun resumeGame() {
        if (navigator.current != Screen.PAUSED) return
        navigator.show(Screen.PLAYING)
        controller.start()
    }

    private fun goHome() {
        controller.stop()
        snakeView.resetEffects()
        dying = false
        settings.recordScore(controller.game?.score ?: 0)
        refreshHomeTexts()
        navigator.show(Screen.HOME)
    }

    private fun showGameOver(score: Int, newBest: Boolean, won: Boolean) {
        gameOverTitle.setText(if (won) R.string.you_win else R.string.game_over)
        gameOverTitle.setTextColor(getColor(if (won) R.color.accent else R.color.food))
        newBestText.visibility = if (newBest) View.VISIBLE else View.GONE
        finalScoreText.text = score.toString()
        gameOverBestText.text = settings.bestScore.toString()
        navigator.show(Screen.GAME_OVER)
    }

    // ---------------------------------------------------------------------------------------
    // GameController.Listener
    // ---------------------------------------------------------------------------------------

    override fun onFrame() {
        snakeView.progress = controller.progress
        snakeView.invalidate()
    }

    override fun onAte(cell: Cell, score: Int) {
        sound.playEat()
        snakeView.playEatAnimation(cell)
        showScore(score, animate = true)
    }

    override fun onDied(score: Int) {
        dying = true
        sound.playGameOver()
        val newBest = score > bestAtGameStart
        settings.recordScore(score)
        showScore(score, animate = false)
        snakeView.playDeathAnimation {
            dying = false
            showGameOver(score, newBest, won = false)
        }
    }

    override fun onWon(score: Int) {
        val newBest = score > bestAtGameStart
        settings.recordScore(score)
        showScore(score, animate = false)
        sound.playEat()
        showGameOver(score, newBest, won = true)
    }

    // ---------------------------------------------------------------------------------------
    // UI helpers
    // ---------------------------------------------------------------------------------------

    private fun showScore(score: Int, animate: Boolean) {
        scoreText.text = score.toString()
        bestText.text = max(settings.bestScore, score).toString()
        if (animate) {
            // Small "pop" on the score each time food is eaten.
            scoreText.animate().cancel()
            scoreText.scaleX = 1.35f
            scoreText.scaleY = 1.35f
            scoreText.animate().scaleX(1f).scaleY(1f).setDuration(200L).start()
        }
    }

    private fun refreshHomeTexts() {
        homeBestText.text = settings.bestScore.toString()
        soundButton.setText(if (settings.soundEnabled) R.string.sound_on else R.string.sound_off)
        controlsButton.setText(if (settings.useDpad) R.string.controls_dpad else R.string.controls_swipe)
    }

    private fun toggleSound() {
        settings.soundEnabled = !settings.soundEnabled
        sound.enabled = settings.soundEnabled
        refreshHomeTexts()
        if (settings.soundEnabled) sound.playEat() // audible confirmation
    }

    private fun toggleControls() {
        settings.useDpad = !settings.useDpad
        applyControlMode()
        refreshHomeTexts()
    }

    /** Shows the D-pad and disables board swipes when D-pad mode is selected, or vice versa. */
    private fun applyControlMode() {
        dpad.visibility = if (settings.useDpad) View.VISIBLE else View.GONE
        snakeView.swipeEnabled = !settings.useDpad
    }

    /** Hides the system bars so edge swipes don't trigger them accidentally. */
    private fun applyImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { insets ->
                insets.hide(WindowInsets.Type.systemBars())
                insets.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }
}
