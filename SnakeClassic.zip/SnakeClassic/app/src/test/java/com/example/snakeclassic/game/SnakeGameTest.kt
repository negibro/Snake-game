package com.example.snakeclassic.game

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

/** Unit tests for the pure game rules. Run with: ./gradlew testDebugUnitTest */
class SnakeGameTest {

    private fun newGame(cols: Int = 20, rows: Int = 20, seed: Int = 1) =
        SnakeGame(cols, rows, Random(seed))

    @Test
    fun startsWithThreeSegmentsInMiddleHeadingRight() {
        val game = newGame(20, 30)
        assertEquals(listOf(Cell(10, 15), Cell(9, 15), Cell(8, 15)), game.snake)
        assertEquals(Direction.RIGHT, game.direction)
        assertEquals(0, game.score)
        assertFalse(game.isOver)
        assertNotNull(game.food)
    }

    @Test
    fun movesOneCellPerStepInCurrentDirection() {
        val game = newGame()
        game.forceFood(Cell(0, 0))
        assertEquals(StepResult.MOVED, game.step())
        assertEquals(Cell(11, 10), game.snake.first())
        assertEquals(3, game.snake.size)
        // previousSnake keeps the positions before the step, for smooth rendering.
        assertEquals(Cell(10, 10), game.previousSnake.first())
    }

    @Test
    fun rejectsDirectReversal() {
        val game = newGame()
        game.forceFood(Cell(0, 0))
        assertFalse(game.queueDirection(Direction.LEFT))
        game.step()
        assertEquals(Direction.RIGHT, game.direction)
        assertEquals(Cell(11, 10), game.snake.first())
    }

    @Test
    fun rejectsRepeatOfCurrentDirection() {
        val game = newGame()
        assertFalse(game.queueDirection(Direction.RIGHT))
    }

    @Test
    fun twoQuickTurnsAreBothHonouredOnConsecutiveSteps() {
        val game = newGame()
        game.forceFood(Cell(0, 0))
        assertTrue(game.queueDirection(Direction.UP))
        assertTrue(game.queueDirection(Direction.LEFT)) // valid relative to the queued UP
        assertFalse(game.queueDirection(Direction.DOWN)) // queue is full
        game.step()
        assertEquals(Cell(10, 9), game.snake.first())
        game.step()
        assertEquals(Cell(9, 9), game.snake.first())
    }

    @Test
    fun reversalIsRejectedAgainstQueuedTurnToo() {
        val game = newGame()
        assertTrue(game.queueDirection(Direction.UP))
        // DOWN would reverse the queued UP, even though it is a legal turn from RIGHT.
        assertFalse(game.queueDirection(Direction.DOWN))
    }

    @Test
    fun eatingFoodGrowsSnakeAndRaisesScore() {
        val game = newGame()
        game.forceFood(Cell(11, 10))
        assertEquals(StepResult.ATE, game.step())
        assertEquals(1, game.score)
        assertEquals(4, game.snake.size)
        assertEquals(Cell(11, 10), game.snake.first())
        val newFood = game.food
        assertNotNull(newFood)
        assertFalse(newFood in game.snake)
    }

    @Test
    fun hittingAWallEndsTheGame() {
        val game = newGame(20, 20)
        game.forceFood(Cell(0, 0))
        var result = StepResult.MOVED
        var steps = 0
        while (result == StepResult.MOVED && steps < 50) {
            result = game.step()
            steps++
        }
        assertEquals(StepResult.DIED, result)
        assertTrue(game.isOver)
        assertEquals(10, steps) // head starts at x=10, wall is at x=20
        // Stepping again keeps reporting the game as over and does not move the snake.
        val headBefore = game.snake.first()
        assertEquals(StepResult.DIED, game.step())
        assertEquals(headBefore, game.snake.first())
        assertFalse(game.queueDirection(Direction.UP))
    }

    @Test
    fun hittingOwnBodyEndsTheGame() {
        val game = newGame(20, 20)
        // Grow to length 6 by eating three foods straight ahead.
        for (i in 1..3) {
            game.forceFood(Cell(10 + i, 10))
            assertEquals(StepResult.ATE, game.step())
        }
        game.forceFood(Cell(0, 0))
        assertEquals(6, game.snake.size)
        game.queueDirection(Direction.UP)
        assertEquals(StepResult.MOVED, game.step())
        game.queueDirection(Direction.LEFT)
        assertEquals(StepResult.MOVED, game.step())
        game.queueDirection(Direction.DOWN)
        assertEquals(StepResult.DIED, game.step())
        assertTrue(game.isOver)
    }

    @Test
    fun movingIntoTheCellTheTailIsLeavingIsAllowed() {
        val game = newGame(20, 20)
        game.forceFood(Cell(11, 10))
        assertEquals(StepResult.ATE, game.step()) // length 4
        game.forceFood(Cell(0, 0))
        game.queueDirection(Direction.UP)
        assertEquals(StepResult.MOVED, game.step())
        game.queueDirection(Direction.LEFT)
        assertEquals(StepResult.MOVED, game.step())
        game.queueDirection(Direction.DOWN)
        // The head now enters the cell the tail is vacating on this very step.
        assertEquals(StepResult.MOVED, game.step())
        assertFalse(game.isOver)
    }

    @Test
    fun foodNeverSpawnsInsideTheSnake() {
        for (seed in 1..300) {
            val game = SnakeGame(5, 5, Random(seed))
            assertNotNull(game.food)
            assertFalse("seed $seed", game.food in game.snake)
        }
    }

    @Test
    fun foodStaysOffTheSnakeAcrossManyMeals() {
        val game = newGame(30, 8, seed = 7)
        // Eat 12 foods placed straight ahead, then check each respawn.
        for (i in 1..12) {
            game.forceFood(Cell(game.snake.first().x + 1, game.snake.first().y))
            assertEquals(StepResult.ATE, game.step())
            assertFalse(game.food in game.snake)
        }
        assertEquals(12, game.score)
        assertEquals(15, game.snake.size)
    }

    @Test
    fun speedIncreasesGraduallyWithScoreAndHasAFloor() {
        val game = SnakeGame(100, 5, Random(3))
        assertEquals(SnakeGame.START_STEP_MS, game.stepIntervalMs)
        game.forceFood(Cell(game.snake.first().x + 1, game.snake.first().y))
        game.step()
        assertEquals(SnakeGame.START_STEP_MS - SnakeGame.STEP_SPEEDUP_MS, game.stepIntervalMs)

        var previous = game.stepIntervalMs
        for (i in 1..45) {
            game.forceFood(Cell(game.snake.first().x + 1, game.snake.first().y))
            game.step()
            assertTrue(game.stepIntervalMs <= previous)
            previous = game.stepIntervalMs
        }
        assertEquals(SnakeGame.MIN_STEP_MS, game.stepIntervalMs)
    }

    @Test
    fun fillingTheWholeBoardWins() {
        val game = SnakeGame(5, 5, Random(1))
        // A path through every cell that is not part of the starting snake (row 2, x = 0..2).
        val path = listOf(
            Cell(3, 2), Cell(3, 1), Cell(2, 1), Cell(1, 1), Cell(0, 1),
            Cell(0, 0), Cell(1, 0), Cell(2, 0), Cell(3, 0), Cell(4, 0),
            Cell(4, 1), Cell(4, 2), Cell(4, 3),
            Cell(3, 3), Cell(2, 3), Cell(1, 3), Cell(0, 3),
            Cell(0, 4), Cell(1, 4), Cell(2, 4), Cell(3, 4), Cell(4, 4)
        )
        var result = StepResult.MOVED
        for ((index, next) in path.withIndex()) {
            val head = game.snake.first()
            val wanted = Direction.values().first { it.dx == next.x - head.x && it.dy == next.y - head.y }
            game.queueDirection(wanted)
            if (index == path.size - 1) {
                // With one free cell left, food must have been placed exactly there.
                assertEquals(next, game.food)
            }
            game.forceFood(next)
            result = game.step()
            if (index < path.size - 1) assertEquals("step $index", StepResult.ATE, result)
        }
        assertEquals(StepResult.WON, result)
        assertTrue(game.isOver)
        assertTrue(game.hasWon)
        assertEquals(22, game.score)
        assertEquals(25, game.snake.size)
        assertNull(game.food)
    }

    @Test
    fun resetStartsAFreshGame() {
        val game = newGame()
        game.forceFood(Cell(11, 10))
        game.step()
        game.reset()
        assertEquals(0, game.score)
        assertEquals(3, game.snake.size)
        assertFalse(game.isOver)
        assertEquals(Direction.RIGHT, game.direction)
    }
}
