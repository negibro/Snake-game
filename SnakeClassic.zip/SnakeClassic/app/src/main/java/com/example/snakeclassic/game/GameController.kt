package com.example.snakeclassic.game

import android.view.Choreographer

/**
 * Drives a [SnakeGame] from the display's frame callbacks.
 *
 * Movement uses a fixed time step: elapsed time accumulates each frame and the game advances one
 * step whenever a full [SnakeGame.stepIntervalMs] has built up. Because the step rate depends on
 * wall-clock time rather than on frames, the snake moves at the same speed on 60 Hz, 90 Hz and
 * 120 Hz screens. [progress] (0..1) tells the renderer how far between two steps we are so it can
 * draw smooth motion.
 *
 * There is only ever one loop: [start] does nothing if the loop is already running.
 * Must be used from the main thread.
 */
class GameController(private val listener: Listener) : Choreographer.FrameCallback {

    interface Listener {
        /** Called once per displayed frame while the loop runs. Redraw here. */
        fun onFrame()

        /** The snake ate [cell]'s food; [score] is the new score. */
        fun onAte(cell: Cell, score: Int)

        /** The snake died. The loop has already stopped. */
        fun onDied(score: Int)

        /** The board was filled. The loop has already stopped. */
        fun onWon(score: Int)
    }

    private val choreographer: Choreographer = Choreographer.getInstance()

    /** The current game, or null before the first [newGame]. */
    var game: SnakeGame? = null
        private set

    /** Fraction (0..1) of the way from the previous step to the next one. */
    var progress: Float = 0f
        private set

    var isRunning: Boolean = false
        private set

    private var lastFrameNanos = 0L
    private var accumulatorMs = 0f

    /** Replaces the current game with a fresh one on a [cols] x [rows] board. The loop is stopped. */
    fun newGame(cols: Int, rows: Int): SnakeGame {
        stop()
        val created = SnakeGame(cols, rows)
        game = created
        accumulatorMs = 0f
        progress = 0f
        return created
    }

    /** Starts (or resumes) the loop. Safe to call repeatedly. */
    fun start() {
        val current = game ?: return
        if (isRunning || current.isOver) return
        isRunning = true
        lastFrameNanos = 0L // forget the time spent paused so we don't jump forward
        choreographer.postFrameCallback(this)
    }

    /** Stops the loop. The game state is kept, so [start] resumes it. */
    fun stop() {
        if (!isRunning) return
        isRunning = false
        choreographer.removeFrameCallback(this)
    }

    /** Forwards a turn request to the game. */
    fun queueDirection(direction: Direction) {
        game?.queueDirection(direction)
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!isRunning) return
        val current = game
        if (current == null || current.isOver) {
            isRunning = false
            return
        }

        if (lastFrameNanos != 0L) {
            // Clamp so a long hiccup (e.g. a GC pause) cannot make the snake teleport.
            val deltaMs = ((frameTimeNanos - lastFrameNanos) / 1_000_000f).coerceIn(0f, MAX_FRAME_MS)
            accumulatorMs += deltaMs
        }
        lastFrameNanos = frameTimeNanos

        var steps = 0
        while (isRunning && accumulatorMs >= current.stepIntervalMs && steps < MAX_STEPS_PER_FRAME) {
            accumulatorMs -= current.stepIntervalMs
            steps++

            when (current.step()) {
                StepResult.MOVED -> Unit
                // The head is now on the cell where the food was eaten.
                StepResult.ATE -> listener.onAte(current.snake.first(), current.score)
                StepResult.DIED -> {
                    finish()
                    progress = 0f
                    listener.onDied(current.score)
                    return
                }
                StepResult.WON -> {
                    finish()
                    progress = 0f
                    listener.onWon(current.score)
                    return
                }
            }
        }

        progress = (accumulatorMs / current.stepIntervalMs).coerceIn(0f, 1f)
        listener.onFrame()

        // A listener callback may have stopped us; only schedule the next frame if still running.
        if (isRunning) {
            choreographer.postFrameCallback(this)
        }
    }

    private fun finish() {
        isRunning = false
        choreographer.removeFrameCallback(this)
    }

    private companion object {
        const val MAX_FRAME_MS = 100f
        const val MAX_STEPS_PER_FRAME = 3
    }
}
