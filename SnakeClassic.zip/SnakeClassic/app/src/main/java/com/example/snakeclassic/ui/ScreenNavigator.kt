package com.example.snakeclassic.ui

import android.view.View

/** The screens of the app. */
enum class Screen { HOME, PLAYING, PAUSED, GAME_OVER }

/**
 * Shows exactly one screen at a time by toggling the stacked layers defined in activity_main.xml.
 *
 * The gameplay layer sits at the bottom and is kept laid out (INVISIBLE, not GONE) while the home
 * screen is shown, so the board size is always known when the player taps Play.
 */
class ScreenNavigator(
    private val gameLayer: View,
    private val homeLayer: View,
    private val pauseLayer: View,
    private val gameOverLayer: View
) {
    var current: Screen = Screen.HOME
        private set

    fun show(screen: Screen) {
        current = screen
        gameLayer.visibility = if (screen == Screen.HOME) View.INVISIBLE else View.VISIBLE
        homeLayer.visibility = if (screen == Screen.HOME) View.VISIBLE else View.GONE
        pauseLayer.visibility = if (screen == Screen.PAUSED) View.VISIBLE else View.GONE
        gameOverLayer.visibility = if (screen == Screen.GAME_OVER) View.VISIBLE else View.GONE
    }
}
