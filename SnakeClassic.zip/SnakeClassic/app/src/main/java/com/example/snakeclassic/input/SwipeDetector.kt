package com.example.snakeclassic.input

import android.content.Context
import android.view.MotionEvent
import com.example.snakeclassic.game.Direction
import kotlin.math.abs

/**
 * Turns raw touch events into up/down/left/right swipes.
 *
 * Unlike a standard fling detector, this fires *while the finger is still moving*, as soon as it
 * has travelled a short distance. That makes steering feel instant. After each swipe the start
 * point is reset to the current finger position, so the player can chain several turns in one
 * continuous drag (e.g. down, then right) without lifting the finger.
 */
class SwipeDetector(context: Context, private val onSwipe: (Direction) -> Unit) {

    private val density = context.resources.displayMetrics.density

    /** Distance (px) the finger must move during a drag to register a swipe. */
    private val moveThresholdPx = MOVE_THRESHOLD_DP * density

    /** Smaller distance (px) accepted for a very quick flick that ends before a MOVE event fires. */
    private val flickThresholdPx = FLICK_THRESHOLD_DP * density

    private var anchorX = 0f
    private var anchorY = 0f
    private var firedInGesture = false

    /** Feed every touch event of the board here. Always returns true: the board consumes touches. */
    fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                anchorX = event.x
                anchorY = event.y
                firedInGesture = false
            }

            MotionEvent.ACTION_MOVE -> {
                if (detect(event.x, event.y, moveThresholdPx)) firedInGesture = true
            }

            MotionEvent.ACTION_UP -> {
                // A quick flick may only report its final position with the UP event.
                if (!firedInGesture) detect(event.x, event.y, flickThresholdPx)
            }

            MotionEvent.ACTION_CANCEL -> firedInGesture = false
        }
        return true
    }

    /** Fires a swipe if the finger moved at least [threshold] px from the anchor. */
    private fun detect(x: Float, y: Float, threshold: Float): Boolean {
        val dx = x - anchorX
        val dy = y - anchorY
        if (abs(dx) < threshold && abs(dy) < threshold) return false

        val direction = if (abs(dx) > abs(dy)) {
            if (dx > 0) Direction.RIGHT else Direction.LEFT
        } else {
            if (dy > 0) Direction.DOWN else Direction.UP
        }
        onSwipe(direction)
        anchorX = x
        anchorY = y
        return true
    }

    private companion object {
        const val MOVE_THRESHOLD_DP = 16f
        const val FLICK_THRESHOLD_DP = 10f
    }
}
