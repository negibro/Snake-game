package com.example.snakeclassic.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.os.Build
import android.os.SystemClock
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import com.example.snakeclassic.R
import com.example.snakeclassic.game.Cell
import com.example.snakeclassic.game.Direction
import com.example.snakeclassic.game.SnakeGame
import com.example.snakeclassic.input.SwipeDetector
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws the game board on a Canvas and reads swipe gestures.
 *
 * Rendering is deliberately cheap so it runs well on budget phones: a handful of rounded
 * rectangles and circles per frame, one pre-built gradient, and no allocations inside [onDraw].
 *
 * The board is always [COLS] cells wide; the number of rows is chosen from the view's height so
 * the cells stay square and the board fills the screen on any aspect ratio.
 */
class SnakeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** The game being displayed (null shows an empty board). */
    var game: SnakeGame? = null
        set(value) {
            field = value
            resetEffects()
            invalidate()
        }

    /** 0..1 progress between the previous and the current snake position, for smooth motion. */
    var progress: Float = 0f

    /** When false (D-pad mode) swipes on the board are ignored. */
    var swipeEnabled: Boolean = true

    /** Called whenever the player swipes. */
    var onSwipe: ((Direction) -> Unit)? = null

    /** Number of rows that fit this view's size, or 0 until the first layout. */
    var boardRows: Int = 0
        private set

    private var readyCallback: ((cols: Int, rows: Int) -> Unit)? = null

    // ----- colours (read once) -----
    private val colorBoard = context.getColor(R.color.board)
    private val colorGrid = context.getColor(R.color.grid)
    private val colorBorder = context.getColor(R.color.panel_stroke)
    private val colorHead = context.getColor(R.color.snake_head)
    private val colorBody = context.getColor(R.color.snake_body)
    private val colorTail = context.getColor(R.color.snake_tail)
    private val colorFood = context.getColor(R.color.food)
    private val colorGlow = context.getColor(R.color.food_glow)

    // ----- reusable paints / objects (no allocation while drawing) -----
    private val boardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = colorBoard }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = colorBorder
        style = Paint.Style.STROKE
        strokeWidth = 2f * resources.displayMetrics.density
    }
    private val gridPaint = Paint().apply {
        color = colorGrid
        strokeWidth = 1f
    }
    private val snakePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0B0F1A.toInt() }
    private val foodPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = colorFood }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()
    private val boardRect = RectF()

    // ----- geometry, recomputed when the size or game changes -----
    private var cellSize = 0f
    private var originX = 0f
    private var originY = 0f
    private var geometryKey = 0L
    private var gridLines = FloatArray(0)
    private var glowRadius = 0f

    // ----- animation state -----
    private var popProgress = -1f
    private var popCell: Cell? = null
    private var popAnimator: ValueAnimator? = null
    private var deathProgress = -1f
    private var deathAnimator: ValueAnimator? = null

    private val swipeDetector = SwipeDetector(context) { direction -> onSwipe?.invoke(direction) }

    /**
     * Runs [callback] with the board size (cols, rows) as soon as the view has been laid out.
     * If the layout is already known, it runs immediately.
     */
    fun whenReady(callback: (cols: Int, rows: Int) -> Unit) {
        if (boardRows > 0) {
            callback(COLS, boardRows)
        } else {
            readyCallback = callback
        }
    }

    /** Plays the short "food eaten" ring animation at [cell]. */
    fun playEatAnimation(cell: Cell) {
        popAnimator?.cancel()
        popCell = cell
        popAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = POP_DURATION_MS
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                popProgress = it.animatedValue as Float
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    popProgress = -1f
                    invalidate()
                }
            })
            start()
        }
    }

    /** Plays the game-over animation (shake, red flash, fade) and then calls [onFinished] once. */
    fun playDeathAnimation(onFinished: () -> Unit) {
        deathAnimator?.cancel()
        deathAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = DEATH_DURATION_MS
            addUpdateListener {
                deathProgress = it.animatedValue as Float
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false

                override fun onAnimationCancel(animation: Animator) {
                    cancelled = true
                }

                override fun onAnimationEnd(animation: Animator) {
                    if (!cancelled) onFinished()
                }
            })
            start()
        }
    }

    /** Stops running animations and clears their visual state. */
    fun resetEffects() {
        popAnimator?.cancel()
        popAnimator = null
        deathAnimator?.cancel()
        deathAnimator = null
        popProgress = -1f
        deathProgress = -1f
    }

    override fun onDetachedFromWindow() {
        resetEffects()
        super.onDetachedFromWindow()
    }

    // ---------------------------------------------------------------------------------------
    // Layout and touch
    // ---------------------------------------------------------------------------------------

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return
        val cell = w / COLS.toFloat()
        boardRows = (h / cell).toInt().coerceIn(MIN_ROWS, MAX_ROWS)
        readyCallback?.let {
            readyCallback = null
            it(COLS, boardRows)
        }
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        // Stop Android 10+ edge-swipe system gestures (back/home) from stealing swipes on the board.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            systemGestureExclusionRects = listOf(Rect(0, 0, right - left, bottom - top))
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!swipeEnabled) return super.onTouchEvent(event)
        if (event.actionMasked == MotionEvent.ACTION_DOWN) {
            // Keep parents (e.g. scroll containers) from taking over the gesture.
            parent?.requestDisallowInterceptTouchEvent(true)
        }
        val handled = swipeDetector.onTouchEvent(event)
        if (event.actionMasked == MotionEvent.ACTION_UP) performClick()
        return handled
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    // ---------------------------------------------------------------------------------------
    // Drawing
    // ---------------------------------------------------------------------------------------

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val current = game
        val gridCols = current?.cols ?: COLS
        val gridRows = current?.rows ?: boardRows
        if (gridRows <= 0 || width <= 0 || height <= 0) return

        updateGeometry(gridCols, gridRows)
        val cell = cellSize

        canvas.save()
        if (deathProgress >= 0f) {
            // Quick decaying horizontal shake.
            val shake = sin(deathProgress * 38f) * (1f - deathProgress) * cell * 0.3f
            canvas.translate(shake, 0f)
        }

        // Board background, subtle grid and border.
        boardRect.set(originX, originY, originX + cell * gridCols, originY + cell * gridRows)
        canvas.drawRoundRect(boardRect, cell * 0.35f, cell * 0.35f, boardPaint)
        canvas.drawLines(gridLines, gridPaint)
        canvas.drawRoundRect(boardRect, cell * 0.35f, cell * 0.35f, borderPaint)

        if (current != null) {
            drawFood(canvas, current, cell)
            drawEatRing(canvas, cell)
            drawSnake(canvas, current, cell)
        }
        canvas.restore()
    }

    /** Recomputes cell size, board origin, grid lines and the glow gradient if anything changed. */
    private fun updateGeometry(gridCols: Int, gridRows: Int) {
        val key = (width.toLong() shl 40) xor (height.toLong() shl 20) xor
            (gridCols.toLong() shl 10) xor gridRows.toLong()
        if (key == geometryKey && cellSize > 0f) return
        geometryKey = key

        cellSize = min(width / gridCols.toFloat(), height / gridRows.toFloat())
        originX = (width - cellSize * gridCols) / 2f
        originY = (height - cellSize * gridRows) / 2f

        // Interior grid lines only (the border is drawn separately).
        val lines = FloatArray(((gridCols - 1) + (gridRows - 1)) * 4)
        var n = 0
        for (c in 1 until gridCols) {
            val x = originX + c * cellSize
            lines[n++] = x; lines[n++] = originY
            lines[n++] = x; lines[n++] = originY + gridRows * cellSize
        }
        for (r in 1 until gridRows) {
            val y = originY + r * cellSize
            lines[n++] = originX; lines[n++] = y
            lines[n++] = originX + gridCols * cellSize; lines[n++] = y
        }
        gridLines = lines

        glowRadius = cellSize * 1.15f
        glowPaint.shader = RadialGradient(
            0f, 0f, glowRadius,
            intArrayOf(withAlpha(colorGlow, 170), withAlpha(colorGlow, 0)),
            floatArrayOf(0.25f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    private fun drawFood(canvas: Canvas, game: SnakeGame, cell: Float) {
        val food = game.food ?: return
        val cx = originX + (food.x + 0.5f) * cell
        val cy = originY + (food.y + 0.5f) * cell
        // Gentle pulsing glow.
        val t = SystemClock.uptimeMillis() / 1000f
        val pulse = 1f + 0.12f * sin(t * 2f * PI.toFloat() * 1.2f)

        canvas.save()
        canvas.translate(cx, cy)
        canvas.scale(pulse, pulse)
        canvas.drawCircle(0f, 0f, glowRadius, glowPaint)
        canvas.drawCircle(0f, 0f, cell * 0.32f, foodPaint)
        canvas.restore()
    }

    private fun drawEatRing(canvas: Canvas, cell: Float) {
        val p = popProgress
        val at = popCell
        if (p < 0f || at == null) return
        ringPaint.color = withAlpha(colorGlow, ((1f - p) * 220f).toInt())
        ringPaint.strokeWidth = cell * 0.14f * (1f - p * 0.6f)
        canvas.drawCircle(
            originX + (at.x + 0.5f) * cell,
            originY + (at.y + 0.5f) * cell,
            cell * (0.4f + 1.1f * p),
            ringPaint
        )
    }

    private fun drawSnake(canvas: Canvas, game: SnakeGame, cell: Float) {
        val cur = game.snake
        val prev = game.previousSnake
        if (cur.isEmpty()) return

        // When the game is over the snake rests exactly on its final cells.
        val p = if (game.isOver) 1f else progress.coerceIn(0f, 1f)

        // Death effect: red flashing, then fade out.
        var tint = 0f
        var alpha = 255
        if (deathProgress >= 0f) {
            tint = (sin(deathProgress * PI.toFloat() * 7f) + 1f) / 2f * 0.85f
            alpha = (255f * (1f - max(0f, (deathProgress - 0.6f) / 0.4f))).toInt().coerceIn(0, 255)
        }

        val last = cur.size - 1
        // Draw tail first so the head ends up on top.
        for (i in last downTo 0) {
            val to = cur[i]
            val from = if (prev.isEmpty()) to else prev[min(i, prev.size - 1)]
            val gx = from.x + (to.x - from.x) * p
            val gy = from.y + (to.y - from.y) * p

            val left = originX + gx * cell
            val top = originY + gy * cell
            val inset = if (i == 0) cell * 0.04f else cell * 0.09f
            rect.set(left + inset, top + inset, left + cell - inset, top + cell - inset)

            val base = if (i == 0) {
                colorHead
            } else {
                blend(colorBody, colorTail, if (last <= 1) 0f else (i - 1).toFloat() / (last - 1))
            }
            snakePaint.color = withAlpha(blend(base, colorFood, tint), alpha)
            canvas.drawRoundRect(rect, cell * 0.3f, cell * 0.3f, snakePaint)

            if (i == 0) drawEyes(canvas, rect.centerX(), rect.centerY(), game.direction, cell, alpha)
        }
    }

    private fun drawEyes(canvas: Canvas, cx: Float, cy: Float, dir: Direction, cell: Float, alpha: Int) {
        eyePaint.alpha = alpha
        val forward = cell * 0.14f
        val side = cell * 0.2f
        val radius = cell * 0.09f
        // Perpendicular to the travel direction is (-dy, dx).
        val px = -dir.dy.toFloat()
        val py = dir.dx.toFloat()
        canvas.drawCircle(cx + dir.dx * forward + px * side, cy + dir.dy * forward + py * side, radius, eyePaint)
        canvas.drawCircle(cx + dir.dx * forward - px * side, cy + dir.dy * forward - py * side, radius, eyePaint)
    }

    // ----- small colour helpers -----

    private fun withAlpha(color: Int, alpha: Int): Int =
        (alpha.coerceIn(0, 255) shl 24) or (color and 0x00FFFFFF)

    /** Linear blend of two opaque colours: t = 0 gives [a], t = 1 gives [b]. */
    private fun blend(a: Int, b: Int, t: Float): Int {
        if (t <= 0f) return a
        val k = t.coerceIn(0f, 1f)
        val r = ((a shr 16 and 0xFF) + ((b shr 16 and 0xFF) - (a shr 16 and 0xFF)) * k).toInt()
        val g = ((a shr 8 and 0xFF) + ((b shr 8 and 0xFF) - (a shr 8 and 0xFF)) * k).toInt()
        val bl = ((a and 0xFF) + ((b and 0xFF) - (a and 0xFF)) * k).toInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
    }

    companion object {
        /** Board width in cells. Rows are derived from the view height. */
        const val COLS = 20
        private const val MIN_ROWS = 12
        private const val MAX_ROWS = 40
        private const val POP_DURATION_MS = 320L
        private const val DEATH_DURATION_MS = 800L
    }
}
