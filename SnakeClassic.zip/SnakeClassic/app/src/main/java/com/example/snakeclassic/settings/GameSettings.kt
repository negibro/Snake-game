package com.example.snakeclassic.settings

import android.content.Context
import android.content.SharedPreferences

/**
 * Persistent player data stored in SharedPreferences (best score, sound on/off, control style).
 * SharedPreferences survive app restarts and phone reboots and need no permissions.
 */
class GameSettings(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var bestScore: Int
        get() = prefs.getInt(KEY_BEST_SCORE, 0).coerceAtLeast(0)
        private set(value) {
            prefs.edit().putInt(KEY_BEST_SCORE, value).apply()
        }

    var soundEnabled: Boolean
        get() = prefs.getBoolean(KEY_SOUND, true)
        set(value) {
            prefs.edit().putBoolean(KEY_SOUND, value).apply()
        }

    /** True when the on-screen D-pad is used instead of swipes. */
    var useDpad: Boolean
        get() = prefs.getBoolean(KEY_DPAD, false)
        set(value) {
            prefs.edit().putBoolean(KEY_DPAD, value).apply()
        }

    /**
     * Saves [score] if it beats the stored best.
     * @return true if a new best score was stored.
     */
    fun recordScore(score: Int): Boolean {
        if (score <= bestScore) return false
        bestScore = score
        return true
    }

    private companion object {
        const val PREFS_NAME = "snake_classic_prefs"
        const val KEY_BEST_SCORE = "best_score"
        const val KEY_SOUND = "sound_enabled"
        const val KEY_DPAD = "use_dpad"
    }
}
