package com.example.snakeclassic.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/**
 * Plays the two sound effects (eat, game over).
 *
 * The sounds are synthesised in code as simple sine-wave beeps, so there are no audio files to
 * license or bundle: they are original. They are written once as small WAV files into the app's
 * private cache folder (no storage permission needed) and loaded into a [SoundPool].
 * Any audio failure is swallowed: the game must never crash because of sound.
 */
class SoundManager(context: Context) {

    private var pool: SoundPool? = null
    private var eatId = 0
    private var gameOverId = 0
    private val loaded = HashSet<Int>()

    /** Master switch controlled by the player's sound toggle. */
    var enabled: Boolean = true

    init {
        try {
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val soundPool = SoundPool.Builder()
                .setMaxStreams(3)
                .setAudioAttributes(attributes)
                .build()
            soundPool.setOnLoadCompleteListener { _, sampleId, status ->
                if (status == 0) loaded.add(sampleId)
            }
            pool = soundPool

            val eatFile = writeIfMissing(context, "eat_v1.wav") { synthEat() }
            val overFile = writeIfMissing(context, "game_over_v1.wav") { synthGameOver() }
            eatId = soundPool.load(eatFile.absolutePath, 1)
            gameOverId = soundPool.load(overFile.absolutePath, 1)
        } catch (e: Exception) {
            // Audio is optional. Continue silently if anything goes wrong.
            pool = null
        }
    }

    fun playEat() = play(eatId)

    fun playGameOver() = play(gameOverId)

    private fun play(soundId: Int) {
        if (!enabled || soundId == 0 || soundId !in loaded) return
        try {
            pool?.play(soundId, VOLUME, VOLUME, 1, 0, 1f)
        } catch (e: Exception) {
            // Ignore: sound is non-essential.
        }
    }

    /** Releases native audio resources. Call from Activity.onDestroy. */
    fun release() {
        try {
            pool?.release()
        } catch (e: Exception) {
            // Ignore.
        }
        pool = null
        loaded.clear()
    }

    // ---------------------------------------------------------------------------------------
    // Sound synthesis
    // ---------------------------------------------------------------------------------------

    /** A short, cheerful two-note "blip" going up in pitch. */
    private fun synthEat(): ByteArray {
        val samples = ArrayList<Short>()
        appendTone(samples, frequency = 660.0, durationMs = 55)
        appendTone(samples, frequency = 990.0, durationMs = 80)
        return toWav(samples.toShortArray())
    }

    /** Four descending notes: a classic "you lost" sound. */
    private fun synthGameOver(): ByteArray {
        val samples = ArrayList<Short>()
        appendTone(samples, frequency = 392.0, durationMs = 140)
        appendTone(samples, frequency = 330.0, durationMs = 140)
        appendTone(samples, frequency = 262.0, durationMs = 140)
        appendTone(samples, frequency = 196.0, durationMs = 320)
        return toWav(samples.toShortArray())
    }

    /** Appends a sine tone with a soft attack/release so it doesn't click. */
    private fun appendTone(out: MutableList<Short>, frequency: Double, durationMs: Int) {
        val count = SAMPLE_RATE * durationMs / 1000
        val fade = (SAMPLE_RATE * 8 / 1000).coerceAtLeast(1) // 8 ms fade in/out
        for (i in 0 until count) {
            val envelope = min(1.0, min(i, count - 1 - i).toDouble() / fade)
            val value = sin(2.0 * PI * frequency * i / SAMPLE_RATE) * envelope * AMPLITUDE
            out.add((value * Short.MAX_VALUE).toInt().toShort())
        }
    }

    /** Wraps 16-bit mono PCM samples in a standard 44-byte WAV header. */
    private fun toWav(pcm: ShortArray): ByteArray {
        val dataSize = pcm.size * 2
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt(36 + dataSize)
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(16) // size of the fmt chunk
        header.putShort(1) // PCM format
        header.putShort(1) // mono
        header.putInt(SAMPLE_RATE)
        header.putInt(SAMPLE_RATE * 2) // byte rate
        header.putShort(2) // block align
        header.putShort(16) // bits per sample
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(dataSize)

        val body = ByteBuffer.allocate(dataSize).order(ByteOrder.LITTLE_ENDIAN)
        for (sample in pcm) body.putShort(sample)

        val out = ByteArrayOutputStream(44 + dataSize)
        out.write(header.array())
        out.write(body.array())
        return out.toByteArray()
    }

    private fun writeIfMissing(context: Context, name: String, bytes: () -> ByteArray): File {
        val file = File(context.cacheDir, name)
        if (!file.exists() || file.length() == 0L) {
            file.writeBytes(bytes())
        }
        return file
    }

    private companion object {
        const val SAMPLE_RATE = 22050
        const val AMPLITUDE = 0.45
        const val VOLUME = 0.8f
    }
}
