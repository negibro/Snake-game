package com.example.snakeclassic.game

import kotlin.math.max
import kotlin.random.Random

/** Outcome of a single call to [SnakeGame.step]. */
enum class StepResult {
    /** The snake moved one cell. */
    MOVED,

    /** The snake moved and ate food (it grew and the score went up). */
    ATE,

    /** The snake hit a wall or its own body. The game is over. */
    DIED,

    /** The snake filled the whole board. The game is over and the player won. */
    WON
}

/**
 * Pure game rules for Snake. This class has no Android dependencies so it can be unit tested on a
 * normal JVM. It knows nothing about time: callers decide when to call [step].
 *
 * @param cols number of grid columns (at least 5)
 * @param rows number of grid rows (at least 5)
 * @param random source of randomness for food placement (injectable for tests)
 */
class SnakeGame(
    val cols: Int,
    val rows: Int,
    private val random: Random = Random.Default
) {
    init {
        require(cols >= 5 && rows >= 5) { "Board must be at least 5x5, was ${cols}x$rows" }
    }

    /** Snake cells, head first. */
    private val body = ArrayDeque<Cell>()

    /** Directions queued by the player but not yet applied (max [MAX_QUEUED_TURNS]). */
    private val pendingTurns = ArrayDeque<Direction>()

    /** The snake as it is now, head first. */
    val snake: List<Cell> get() = body

    /** The snake as it was before the most recent step. The renderer uses this to animate movement. */
    var previousSnake: List<Cell> = emptyList()
        private set

    /** Current food position, or null only when the board is completely full. */
    var food: Cell? = null
        private set

    var score: Int = 0
        private set

    /** The direction the snake moved in on its last step (or will move in if no turn is queued). */
    var direction: Direction = Direction.RIGHT
        private set

    var isOver: Boolean = false
        private set

    var hasWon: Boolean = false
        private set

    /** Time between steps in milliseconds. Shrinks gradually as the score rises. */
    val stepIntervalMs: Long
        get() = max(MIN_STEP_MS, START_STEP_MS - score.toLong() * STEP_SPEEDUP_MS)

    init {
        reset()
    }

    /** Starts a fresh game: 3-segment snake in the middle heading right, one piece of food. */
    fun reset() {
        body.clear()
        pendingTurns.clear()
        score = 0
        isOver = false
        hasWon = false
        direction = Direction.RIGHT

        val headX = cols / 2
        val headY = rows / 2
        body.addLast(Cell(headX, headY))
        body.addLast(Cell(headX - 1, headY))
        body.addLast(Cell(headX - 2, headY))
        previousSnake = body.toList()
        food = null
        spawnFood()
    }

    /**
     * Queues a turn requested by the player. Returns true if it was accepted.
     *
     * A turn is rejected when it repeats the direction already being travelled, would reverse the
     * snake into itself, or the queue is full. The comparison is made against the *last queued*
     * direction, so two quick swipes (e.g. up then left) are both honoured on consecutive steps
     * without ever allowing a 180-degree turn.
     */
    fun queueDirection(requested: Direction): Boolean {
        if (isOver) return false
        val reference = pendingTurns.lastOrNull() ?: direction
        if (requested == reference || requested.isOpposite(reference)) return false
        if (pendingTurns.size >= MAX_QUEUED_TURNS) return false
        pendingTurns.addLast(requested)
        return true
    }

    /** Advances the game by one grid step and reports what happened. */
    fun step(): StepResult {
        if (isOver) return if (hasWon) StepResult.WON else StepResult.DIED

        if (pendingTurns.isNotEmpty()) {
            direction = pendingTurns.removeFirst()
        }

        val head = body.first()
        val next = Cell(head.x + direction.dx, head.y + direction.dy)

        // Wall collision.
        if (next.x < 0 || next.x >= cols || next.y < 0 || next.y >= rows) {
            isOver = true
            return StepResult.DIED
        }

        val willEat = next == food

        // Body collision. The tail cell is vacated on this step unless we are growing, so moving
        // into the current tail cell is legal when not eating.
        val tail = body.last()
        val hitsBody = body.any { it == next } && !(next == tail && !willEat)
        if (hitsBody) {
            isOver = true
            return StepResult.DIED
        }

        previousSnake = body.toList()
        body.addFirst(next)

        if (!willEat) {
            body.removeLast()
            return StepResult.MOVED
        }

        score += 1
        if (body.size >= cols * rows) {
            // No empty cell left for food: the player has filled the board.
            food = null
            isOver = true
            hasWon = true
            return StepResult.WON
        }
        spawnFood()
        return StepResult.ATE
    }

    /** Picks a uniformly random empty cell for the food. Never returns a cell occupied by the snake. */
    private fun spawnFood() {
        val occupied = BooleanArray(cols * rows)
        for (cell in body) occupied[cell.y * cols + cell.x] = true

        val freeCount = occupied.count { !it }
        if (freeCount == 0) {
            food = null
            return
        }
        var pick = random.nextInt(freeCount)
        for (index in occupied.indices) {
            if (!occupied[index]) {
                if (pick == 0) {
                    food = Cell(index % cols, index / cols)
                    return
                }
                pick--
            }
        }
    }

    /** Test hook: places food at [cell]. Only valid for empty in-bounds cells. */
    internal fun forceFood(cell: Cell) {
        require(cell.x in 0 until cols && cell.y in 0 until rows) { "Food out of bounds: $cell" }
        require(cell !in body) { "Food cannot be placed on the snake: $cell" }
        food = cell
    }

    companion object {
        const val START_STEP_MS = 180L
        const val MIN_STEP_MS = 75L
        const val STEP_SPEEDUP_MS = 3L
        const val MAX_QUEUED_TURNS = 2
    }
}
